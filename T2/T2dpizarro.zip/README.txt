Tarea 2 Diego Pizarro W.

El desarrollo de la tarea esta en el archivo tarea2_v0.py

Para correr la tarea, todos los archivos del zip deben estar en el mismo directorio