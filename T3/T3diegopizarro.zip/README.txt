Tarea 3 Diego Pizarro W.

Para que ejecutar bien la tarea, el archivo "tarea3_v1.py" debe estar en el mismo directorio que los archivos del repo de grafica